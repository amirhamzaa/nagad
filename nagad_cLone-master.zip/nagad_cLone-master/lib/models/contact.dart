class AppContact {
  String cId = "";
  String cImage = "";
  String cType = "";
  String cNumber = "";
  String cName = "";

  AppContact({required this.cId, required this.cImage, required this.cType, required this.cNumber,
    required this.cName});
}
class Transactions {
  int tId = 0;
  String tIcon= "";
  String tTitle = "";
  String tBody = "";
  String tTime = "";
  String tAmt = "";
  String tAmtIcon = "";
  String tType = "";

  Transactions({required this.tId, required this.tIcon, required this.tTitle, required this.tBody,
    required this.tTime, required this.tAmt, required this.tAmtIcon, required this.tType});
}
class AppText {
  static const String placeholder = "Not implemented! Will add soon.";
}